0.1.2 / 2013-11-21
==================

	* Parity update for EaselJS 0.7.0
	* Due to API changes in EaselJS this version will break old projects.
	* * For details checkout the EaselJS changelog; https://github.com/CreateJS/EaselJS/blob/master/VERSIONS.txt

0.1.1 / 2013-05-15
==================

	* Update for parity with EaselJS 0.6.1.


0.1.0 / 2013-02-14
==================

	* Initial Release. Parity with EaselJS 0.6.0.
